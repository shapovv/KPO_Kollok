package org.example;

public class ComputerFacade {
    PowerSupply powerSupply;
    Controller controller;
    Motherboard motherboard;
    Memory memory;
    Cooler cooler;
    OperatingSystem operatingSystem;
    Keyboard keyboard;
    Mouse mouse;
    Screen screen;

    public ComputerFacade(PowerSupply powerSupply,
                          Controller controller,
                          Motherboard motherboard,
                          Memory memory,
                          Cooler cooler,
                          OperatingSystem operatingSystem,
                          Keyboard keyboard,
                          Mouse mouse,
                          Screen screen) {

        this.powerSupply = powerSupply;
        this.controller = controller;
        this.motherboard = motherboard;
        this.memory = memory;
        this.cooler = cooler;
        this.operatingSystem = operatingSystem;
        this.keyboard = keyboard;
        this.mouse = mouse;
        this.screen = screen;
    }

    public void On() {
        System.out.println("Включение компьютера...");
        powerSupply.on();
        controller.on();
        controller.check();
        memory.loading();
        motherboard.start();
        memory.on();
        cooler.on();
        cooler.force(5);
        operatingSystem.on();
        keyboard.on();
        mouse.on();
        screen.up();
    }


    public void Off() {
        System.out.println("Выключение компьютера...");
        screen.down();
        mouse.off();
        keyboard.off();
        operatingSystem.off();
        cooler.force(0);
        cooler.off();
        memory.loading();
        memory.off();
        motherboard.stop();
        controller.off();
        powerSupply.off();
    }

}
