package org.example;

public class Memory {
    String description;

    public Memory(String description) {
        this.description = description;
    }
    public void loading() {
        System.out.println(description + " готовa к работе");
    }

    public void on() {
        System.out.println(description + " - on");
    }

    public void off() {
        System.out.println(description + " - off");
    }

    public String toString() {
        return description;
    }
}
