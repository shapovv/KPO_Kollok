package org.example;

public class Motherboard {
    String description;

    public Motherboard(String description) {
        this.description = description;
    }

    public void start() {
        System.out.println(description + " - запустилась");
    }

    public void stop() {
        System.out.println(description + " - отключена");
    }

    public String toString() {
        return description;
    }
}
