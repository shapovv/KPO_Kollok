package org.example;

public class Screen {
    String description;

    public Screen(String description) {
        this.description = description;
    }

    public void up() {
        System.out.println(description + " - включен");
    }

    public void down() {
        System.out.println(description + " - выключен");
    }


    public String toString() {
        return description;
    }
}

