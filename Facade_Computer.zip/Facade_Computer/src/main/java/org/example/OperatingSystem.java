package org.example;

public class OperatingSystem {
    String description;

    public OperatingSystem(String description) {
        this.description = description;
    }

    public void on() {
        System.out.println(description + " - on");
    }

    public void off() {
        System.out.println(description + " - off");
    }

    public String toString() {
        return description;
    }
}


