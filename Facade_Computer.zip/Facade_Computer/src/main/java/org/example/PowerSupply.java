package org.example;

public class PowerSupply {

    String description;

    public PowerSupply(String description) {
        this.description = description;
    }

    public void on() {
        System.out.println(description + " - on");
    }

    public void off() {
        System.out.println(description + " - off");
    }

    public String toString() {
        return description;
    }
}
