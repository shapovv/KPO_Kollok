package org.example;

public class Mouse {
    String description;

    public Mouse(String description) {
        this.description = description;
    }

    public void on() {
        System.out.println(description + " - on");
    }

    public void off() {
        System.out.println(description + " - off");
    }

    public String toString() {
        return description;
    }
}


