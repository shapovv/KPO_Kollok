package org.example;

public class Controller {
    String description;

    public Controller(String description) {
        this.description = description;
    }

    public void on() {
        System.out.println(description + " - on");
    }
    public void check() {
        System.out.println(description + " проводится проверка всех систем");
    }

    public void off() {
        System.out.println(description + " - off");
    }

    public String toString() {
        return description;
    }
}
