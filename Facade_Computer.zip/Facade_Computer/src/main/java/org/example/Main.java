package org.example;

public class Main {
    public static void main(String[] args) {
        PowerSupply powerSupply = new PowerSupply("Контроллер питания SN650801");
        Controller controller = new Controller("SMC");
        Motherboard motherboard = new Motherboard("Intel Core i5");
        Memory memory = new Memory("8 ГБ 2133 MHz LPDDR3");
        Cooler cooler = new Cooler("Вентилятор левый");
        OperatingSystem operatingSystem = new OperatingSystem("MacOS Big Sur версия 11.6");
        Keyboard keyboard = new Keyboard("Magic Keyboard");
        Mouse mouse = new Mouse("Magic Mouse");
        Screen screen = new Screen("Встроенный дисплей Retina 13,3-дюймовый (2560 × 1600)");
        ComputerFacade Computer =
                new ComputerFacade(powerSupply, controller, motherboard,
                        memory, cooler, operatingSystem, keyboard, mouse, screen);

        Computer.On();
        Computer.Off();
    }
}