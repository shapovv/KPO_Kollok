package org.example;

public class Cooler {
    String description;

    public Cooler(String description) {
        this.description = description;
    }

    public void on() {
        System.out.println(description + " - on");
    }

    public void force(int param) {
        System.out.println(description + " работает с мощностью " + param + "%");
    }


    public void off() {
        System.out.println(description + " - off");
    }

    public String toString() {
        return description;
    }
}

