package org.example;

public class PrintInkjet implements PrintBehavior {

    @Override
    public void print() {
        System.out.println("Я печатаю струйной печатью.");
    }
}
