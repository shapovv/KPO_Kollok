package org.example;

public class ScanColor implements ScanBehavior {

    @Override
    public void scan() {
        System.out.println("Я умею делать цветные сканы.");
    }
}


