package org.example;

public interface PrintBehavior {
    public void print();
}
