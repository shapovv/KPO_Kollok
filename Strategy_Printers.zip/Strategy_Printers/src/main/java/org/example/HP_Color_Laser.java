
package org.example;

public class HP_Color_Laser extends Printer {

    public HP_Color_Laser() {

        scanBehavior = new ScanColor();
        printBehavior = new PrintLaser();

    }

    public void display() {
        System.out.println("Я принтер HP LaserJet Pro.");
    }
}


