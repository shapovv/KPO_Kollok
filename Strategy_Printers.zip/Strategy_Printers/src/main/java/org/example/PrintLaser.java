package org.example;

public class PrintLaser implements PrintBehavior {

    @Override
    public void print() {
        System.out.println("Я печатаю лазерной печатью.");
    }
}

