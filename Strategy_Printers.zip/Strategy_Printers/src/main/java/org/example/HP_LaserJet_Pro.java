package org.example;

public class HP_LaserJet_Pro extends Printer {

    public HP_LaserJet_Pro() {

        scanBehavior = new ScanBW();
        printBehavior = new PrintLaser();

    }

    public void display() {
        System.out.println("Я принтер HP LaserJet Pro.");
    }
}

