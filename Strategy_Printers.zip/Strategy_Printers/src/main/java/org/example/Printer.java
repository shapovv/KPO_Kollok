package org.example;

public abstract class Printer {
    PrintBehavior printBehavior;
    ScanBehavior scanBehavior;

    public Printer() {
    }

    public void setPrintBehavior(PrintBehavior pb) {
        printBehavior = pb;
    }

    public void setScanBehavior(ScanBehavior sb) {
        scanBehavior = sb;
    }

    abstract void display();

    public void performPrint() {
        printBehavior.print();
    }

    public void performScan() {
        scanBehavior.scan();
    }

}

