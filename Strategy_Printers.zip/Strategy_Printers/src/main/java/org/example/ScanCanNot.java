package org.example;

public class ScanCanNot implements ScanBehavior {

    @Override
    public void scan() {
        System.out.println("Я не умею сканировать!");
    }
}

