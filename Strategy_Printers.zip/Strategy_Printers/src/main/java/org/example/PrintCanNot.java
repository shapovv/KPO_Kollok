package org.example;

public class PrintCanNot implements PrintBehavior {

    @Override
    public void print() {
        System.out.println("Я не могу печатать!");
    }
}
