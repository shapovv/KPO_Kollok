package org.example;

public class Epson_L800 extends Printer {

    public Epson_L800() {

        scanBehavior = new ScanCanNot();
        printBehavior = new PrintInkjet();

    }

    public void display() {
        System.out.println("Я принтер Epson L800.");
    }
}

