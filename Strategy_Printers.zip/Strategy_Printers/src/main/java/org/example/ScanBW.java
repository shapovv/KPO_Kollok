package org.example;

public class ScanBW implements ScanBehavior {

    @Override
    public void scan() {
        System.out.println("Я умею делать чёрно-белые сканы.");
    }
}


