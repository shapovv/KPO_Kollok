package org.example;

public class Main {
    public static void main(String[] args) {
        Printer myPrinter = new Epson_L800();
        myPrinter.display();
        myPrinter.performScan();
        myPrinter.performPrint();


        Printer testPrinter = new HP_Color_Laser();
        testPrinter.display();
        testPrinter.performScan();
        testPrinter.performPrint();
        testPrinter.setPrintBehavior(new PrintCanNot());
        testPrinter.performPrint();

    }
}
