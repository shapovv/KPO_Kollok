package org.example;

public interface ScanBehavior {
    public void scan();
}
